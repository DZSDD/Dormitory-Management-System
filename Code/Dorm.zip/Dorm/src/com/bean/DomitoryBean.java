package com.bean;
public class DomitoryBean {

    private int Domitory_ID ;
    private int Domitory_BuildingID ;
    private String Domitory_Name ;
    private String Domitory_Type ;
    private String Domitory_Number ;
    private String Domitory_Tel ;
	public int getDomitory_ID() {
		return Domitory_ID;
	}
	public void setDomitory_ID(int domitoryID) {
		Domitory_ID = domitoryID;
	}
	public int getDomitory_BuildingID() {
		return Domitory_BuildingID;
	}
	public void setDomitory_BuildingID(int domitoryBuildingID) {
		Domitory_BuildingID = domitoryBuildingID;
	}
	public String getDomitory_Name() {
		return Domitory_Name;
	}
	public void setDomitory_Name(String domitoryName) {
		Domitory_Name = domitoryName;
	}
	public String getDomitory_Type() {
		return Domitory_Type;
	}
	public void setDomitory_Type(String domitoryType) {
		Domitory_Type = domitoryType;
	}
	public String getDomitory_Number() {
		return Domitory_Number;
	}
	public void setDomitory_Number(String domitoryNumber) {
		Domitory_Number = domitoryNumber;
	}
	public String getDomitory_Tel() {
		return Domitory_Tel;
	}
	public void setDomitory_Tel(String domitoryTel) {
		Domitory_Tel = domitoryTel;
	}
    
	private String Building_Name ;
	public String getBuilding_Name() {
		return Building_Name;
	}
	public void setBuilding_Name(String buildingName) {
		Building_Name = buildingName;
	}
}
